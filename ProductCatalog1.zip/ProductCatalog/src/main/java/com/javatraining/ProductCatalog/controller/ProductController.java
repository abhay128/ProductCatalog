package com.javatraining.ProductCatalog.controller;

import com.javatraining.ProductCatalog.model.Product;
import com.javatraining.ProductCatalog.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
public class ProductController {
    @Autowired
    private ProductService productService;

    @RequestMapping("/products")
    public Iterable<Product> getAllProducts() {
        return productService.getAllProducts();

    }

    @RequestMapping("/products/{id}")
    public Product getProduct(@PathVariable int id) {
        return productService.getProduct(id);

    }

    @RequestMapping(method= RequestMethod.POST , value="/products")
    public void addProduct(@RequestBody Product product) {
        System.out.println(product);
        productService.addProduct(product);

    }
}
