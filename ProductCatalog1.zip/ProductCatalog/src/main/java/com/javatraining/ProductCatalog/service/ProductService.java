package com.javatraining.ProductCatalog.service;

import com.javatraining.ProductCatalog.model.Product;
import com.javatraining.ProductCatalog.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ProductService {
    @Autowired
    public ProductRepository productRepository;

    public Iterable<Product> getAllProducts(){
        return productRepository.findAll();

    }

    public Product getProduct(int id) {
        return productRepository.findById(id).get();
    }

    public void addProduct(Product product) {
        productRepository.save(product);
    }

}
