package com.javatraining.ProductCatalog.repository;

import com.javatraining.ProductCatalog.model.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, Integer> {


}
